
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.*;
import java.awt.*;

public class Draw extends JFrame implements MouseListener{

	public static int x=(int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getWidth();
	public static int y=(int)java.awt.Toolkit.getDefaultToolkit().getScreenSize().getHeight();
	
	public static int width_buttonPanel=305;
	public static int centerx=(x-width_buttonPanel)/2;    //axes
	public static int centery=y/2;                 
	
	public static int gridInterval=50;
	public static boolean flag_scale=true;
	
	public static double arrX[]=new double[2000];
	public static double arrY[]=new double[2000];
	public static double[] interval_line;
	public static ArrayList<Point[]> list_line=new ArrayList<>();
	
	
	public static double[] polygonX;
	public static double[] polygonY;
	public static double[] interval_polygon;
	public static int polygon_pos_x;
	public static int polygon_pos_y;
	
		
	private int nPoints_polygon = 0;
	private boolean DRAW_Polygon=false;

	
	JRadioButton btn_solid=new JRadioButton("Solid");
	JRadioButton btn_dotted=new JRadioButton("Dotted");
	JRadioButton btn_dashed=new JRadioButton("Dashed");
	JTextField jtf_thickness = new JTextField("1");
	public static int flag_shapeProperties;
	public static int flag_shapeThickness;
	
	public static int flag_mouse_shape;
	
	public static ArrayList<Integer> listX_line;
	public static ArrayList<Integer> listY_line;
	
	
	JButton apply_btn=new JButton("Help");
	JButton clear_btn=new JButton("Remove all");
	
	JRadioButton mouse_line_rbtn=new JRadioButton("Line");
	JRadioButton mouse_polygon_rbtn=new JRadioButton("Polygon");
	JRadioButton mouse_circle_rbtn = new JRadioButton("Circle");
	
	JRadioButton line_rbtn=new JRadioButton("Draw Line");
	
	JRadioButton polygon_rbtn=new JRadioButton("Draw Polygon");
	JRadioButton circle_rbtn = new JRadioButton("Draw Circle");
	
	JRadioButton polygon_regular_rbtn=new JRadioButton("Regular: sides");
	JButton polygon_regular_okbtn=new JButton("Draw");
	JRadioButton polygon_irregular_rbtn=new JRadioButton("Irregular: sides");
	JButton polygon_irregular_okbtn=new JButton("Draw");
	JButton polygon_color = new JButton("Color");
	JButton irregular_polygon_color = new JButton("Color");
	JButton irregular_polygon_linecolor=new JButton("Line color");
	JButton irregular_polygon_shapecolor=new JButton("Shape color");
	JButton circle_btn = new JButton("Draw Circle");
	
	
	JRadioButton line_DDA=new JRadioButton("DDA");
	JRadioButton line_BLA=new JRadioButton("BLA");

	JButton line_okbtn=new JButton("Draw");


	JTextField polygon_num_sides1 = new JTextField();
	JTextField polygon_num_sides2 = new JTextField();
	
	ShapePanel shapePanel=new ShapePanel();
	
	JLabel label;
	
 
	
	public Draw(){
		
		label = new JLabel("", JLabel.RIGHT);
		shapePanel.addMouseListener(this);
		shapePanel.add(label);
		JPanel buttonPanel=new JPanel();
		buttonPanel.setBackground(Color.white);
		
		JPanel shapePropertiesPanel=new JPanel();
		shapePropertiesPanel.setPreferredSize(new Dimension(width_buttonPanel,80));
		shapePropertiesPanel.setBackground(Color.lightGray);
		shapePropertiesPanel.setLayout(new GridLayout(4,2));
		shapePropertiesPanel.add(new JLabel("Line Attributes"));
		shapePropertiesPanel.add(new JLabel(""));
		shapePropertiesPanel.add(btn_solid);
		btn_solid.setOpaque(false);
		shapePropertiesPanel.add(btn_dotted);
		btn_dotted.setOpaque(false);
		shapePropertiesPanel.add(btn_dashed);
		btn_dashed.setOpaque(false);
		shapePropertiesPanel.add(new JLabel(""));
		shapePropertiesPanel.add(new JLabel("Thickness"));
		shapePropertiesPanel.add(jtf_thickness);

		JPanel linePanel=new JPanel();
		linePanel.setBackground(Color.lightGray);
		linePanel.setPreferredSize(new Dimension(width_buttonPanel,100));
		linePanel.setLayout(new GridLayout(6,2,2,2));
		linePanel.add(line_rbtn);
		line_rbtn.setOpaque(false);
		linePanel.add(new JLabel(""));
		linePanel.add(line_DDA);
		line_DDA.setOpaque(false);
		linePanel.add(line_BLA);
		line_BLA.setOpaque(false);
		linePanel.add(line_okbtn);

		
		JPanel polygonPanel_full=new JPanel();
		polygonPanel_full.setPreferredSize(new Dimension(width_buttonPanel, 500));
		polygonPanel_full.setLayout(new GridLayout(1,3));
		
		
		JPanel polygonPanel1=new JPanel();
		JPanel polygonPanel2=new JPanel();
		
		//adding code to display for regular
		polygonPanel1.setBackground(Color.lightGray);
		polygonPanel1.setPreferredSize(new Dimension(width_buttonPanel,50));
		polygonPanel1.setLayout(new GridLayout(2,1));
		polygonPanel1.add(polygon_regular_rbtn);
		polygon_regular_rbtn.setOpaque(false);
		polygonPanel1.add(new JLabel(""));
		polygonPanel1.add(new JLabel(""));
		//polygonPanel1.add(new JLabel("Num Sides",SwingConstants.CENTER));
		polygonPanel1.add(new JLabel(""));
		polygonPanel1.add(polygon_num_sides1);
		
		polygonPanel1.add(polygon_regular_okbtn);
		polygonPanel1.add(new JLabel(""));
		polygonPanel1.add(polygon_color);
		//end of code
		
		polygonPanel2.setBackground(Color.lightGray);
		polygonPanel2.setPreferredSize(new Dimension(width_buttonPanel,200));
		polygonPanel2.setLayout(new GridLayout(10,1,30,0));
		polygonPanel2.add(polygon_irregular_rbtn);
		polygon_irregular_rbtn.setOpaque(false);
		//polygonPanel2.add(new JLabel(""));
		//polygonPanel2.add(new JLabel(""));
		//polygonPanel2.add(new JLabel("Num Sides",SwingConstants.LEFT));
		polygonPanel2.add(new JLabel(""));
		polygonPanel2.add(polygon_num_sides2);
		//polygonPanel2.add(new JLabel(""));
		polygonPanel2.add(polygon_irregular_okbtn);
		polygonPanel2.add(irregular_polygon_linecolor);
		polygonPanel2.add(irregular_polygon_shapecolor);
		
		polygonPanel_full.setBackground(Color.lightGray);
		polygonPanel_full.setLayout(new FlowLayout(FlowLayout.LEFT));
		polygonPanel_full.add(polygon_rbtn);
		polygon_rbtn.setOpaque(false);
		polygonPanel_full.add(polygonPanel1);
		polygonPanel_full.add(polygonPanel2);

		
		JPanel circlePanel = new JPanel();
		circlePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		circlePanel.setBackground(Color.LIGHT_GRAY);
		circlePanel.setPreferredSize(new Dimension(width_buttonPanel,65));
		circlePanel.add(circle_rbtn);
		circle_rbtn.setOpaque(false);
		circlePanel.add(new JLabel(""));
		circlePanel.add(circle_btn);
		
		JPanel mousePanel=new JPanel();
		mousePanel.setBackground(Color.lightGray);
		mousePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		mousePanel.setLayout(new GridLayout(2,3));
		mousePanel.setPreferredSize(new Dimension(width_buttonPanel,40));
		mousePanel.add(mouse_line_rbtn);
		mouse_line_rbtn.setOpaque(false);	
		mousePanel.add(mouse_polygon_rbtn);
		mouse_polygon_rbtn.setOpaque(false);
		mousePanel.add(mouse_circle_rbtn);
		mouse_polygon_rbtn.setOpaque(true);
		
		ButtonGroup shapePropertiesButton=new ButtonGroup();
		shapePropertiesButton.add(btn_solid);
		shapePropertiesButton.add(btn_dotted);
		shapePropertiesButton.add(btn_dashed);
		btn_solid.setSelected(true);
		
		ButtonGroup line_properties=new ButtonGroup();
		line_properties.add(line_DDA);
		line_properties.add(line_BLA);
		line_DDA.setSelected(true);
		
		ButtonGroup keyboard_shapeButton=new ButtonGroup();   //choosing only between the following:
		keyboard_shapeButton.add(line_rbtn);		
		keyboard_shapeButton.add(polygon_rbtn);
		keyboard_shapeButton.add(circle_rbtn);
		polygon_rbtn.setSelected(true);

		ButtonGroup keyboard_shapeButton_polygon=new ButtonGroup();   //choosing only one
		keyboard_shapeButton_polygon.add(polygon_regular_rbtn);
		keyboard_shapeButton_polygon.add(polygon_irregular_rbtn);
		polygon_regular_rbtn.setSelected(true);
		
		
		
		buttonPanel.add(shapePropertiesPanel);		
		buttonPanel.add(polygonPanel_full);
		buttonPanel.setPreferredSize(new Dimension(width_buttonPanel,y));
		
		
		
		shapePanel.setPreferredSize(java.awt.Toolkit.getDefaultToolkit().getScreenSize());
		getContentPane().add(buttonPanel, BorderLayout.WEST);
		getContentPane().add(shapePanel, BorderLayout.CENTER);
		pack();
		setVisible(true);
		
		ActionListener listener=new ActionListener(){
			public void actionPerformed(ActionEvent event){
				Shape drawShape = null;
				
				
					if(event.getSource()!=clear_btn){
						
					
						if(line_rbtn.isSelected()){}//CODES FOR LINE (DDA/BLA)
						
						
						
						else if(polygon_rbtn.isSelected()){
							
							flag_shapeThickness=Integer.parseInt(jtf_thickness.getText());
							
							if(btn_solid.isSelected()){
								flag_shapeProperties=1;
							}
							else if(btn_dotted.isSelected()){
								flag_shapeProperties=2;
							}
							else if(btn_dashed.isSelected()){
								flag_shapeProperties=3;
							}
							
					
							if(polygon_regular_rbtn.isSelected()){
								int numSides=Integer.parseInt(polygon_num_sides1.getText());
								
								//adding code to display box
			
								
								polygonX=new double[numSides+1];
								polygonY=new double[numSides+1];
								
								if(event.getSource()==polygon_regular_okbtn){
									
									String radius_string_x=JOptionPane.showInputDialog("Enter x coordinate");
											int position_x=Integer.parseInt(radius_string_x);
											
											String radius_string_y=JOptionPane.showInputDialog("Enter y coordinate");
											int position_y=Integer.parseInt(radius_string_y);
											
											String r_polygon=JOptionPane.showInputDialog("Enter r");
											int r=Integer.parseInt(r_polygon);
											

								
								int greater=(Math.max(Math.abs(position_x), Math.abs(position_y)));
								
							//	int r = 0;
								int originalRadius=r;
								
								double radius=originalRadius;
								
								
								
								double percentage=.40;
								if((radius+greater)<y*percentage){
									double differenceTimes=(y*percentage)/(radius+greater);
									radius=radius*differenceTimes;
									position_x=(int)(position_x*differenceTimes);
									position_y=(int)(position_y*differenceTimes);
								}
								else if((radius+greater)>y*percentage){
									double numberTimesBigger=1;
									
									while(((radius+greater)/numberTimesBigger)>y*percentage){
										numberTimesBigger+=0.1;
									}
									radius=radius/numberTimesBigger;
									position_x=(int)(position_x/numberTimesBigger);
									position_y=(int)(position_y/numberTimesBigger);
								}
								
								polygon_pos_x=(int)(position_x);
								polygon_pos_y=(int)(position_y);
														
								polygonX=new double[numSides+1];
								polygonY=new double[numSides+1];
								
								double theta=2*Math.PI/numSides;
								
								for(int i=0;i<numSides;i++){
									polygonX[i]=radius*Math.cos(theta*i);
									polygonY[i]=radius*Math.sin(theta*i);
								}
								
								polygonX[numSides]=radius*Math.cos(0);
								polygonY[numSides]=radius*Math.sin(0);
								
							}//regular polygon
							}
							else if(polygon_irregular_rbtn.isSelected()){
								int numSides=Integer.parseInt(polygon_num_sides2.getText());
								
								polygonX=new double[numSides+1];
								polygonY=new double[numSides+1];
								
								if(event.getSource()==polygon_irregular_okbtn){

									
									//input each coordinate into array
										for(int i=0;i<numSides;i++){
										     JTextField field1 = new JTextField();
										        JTextField field2 = new JTextField();
										        
										        Object [] fields = {
										            "Enter x coordinate:", field1,
										            "Enter y coordinate:", field2,
										        
										            
										        };
										        
										        JOptionPane.showConfirmDialog(null,fields,"Irregular Polygon: Input",JOptionPane.OK_CANCEL_OPTION);

										        String string_x = field1.getText();
										        String string_y = field2.getText();
											//String string_x=JOptionPane.showInputDialog("Enter x coordinate:");   //message to be printed  ---STRING!!
											int int_x=Integer.parseInt(string_x);     //coordinate x
											
											//String string_y=JOptionPane.showInputDialog("Enter y coordinate:");   //message to be printed  ----STRING!!
											int int_y=Integer.parseInt(string_y);      // y coordinate
											 
											
											//storing these coordinates in the 2 arrays respectively
											if(i==0){
												polygonX[numSides]=int_x;
												polygonY[numSides]=int_y;
											}//if
											
											polygonX[i]=int_x;
											polygonY[i]=int_y;
										}//for
									
								}
								
								if(event.getSource()==irregular_polygon_linecolor){
								Color initialcolor=Color.RED; 	
								Component f = null;
								Color c=JColorChooser.showDialog(f,"Choose",initialcolor); 
								g2.setColor(initialcolor);
								drawShape=new Polygon();
								shapePanel.setShape(drawShape);
								}
								if(event.getSource()==irregular_polygon_shapecolor){
									Color initialcolor=Color.RED; 
									Component f = null;
									Color c=JColorChooser.showDialog(f,"Choose",initialcolor);  
									g2.setColor(initialcolor);
									drawShape=new Polygon();
									shapePanel.setShape(drawShape);
									}
							}//irregular polygon
								
							drawShape=new Polygon();
						
							flag_scale=false;
						}//end polygon for loop
						
						
					shapePanel.setShape(drawShape);
					repaint();
					}
					
					else{}
				}
	
		};
		
		apply_btn.addActionListener(listener);
		polygon_irregular_okbtn.addActionListener(listener);
		polygon_regular_okbtn.addActionListener(listener);
		clear_btn.addActionListener(listener);
		irregular_polygon_linecolor.addActionListener(listener);
		irregular_polygon_shapecolor.addActionListener(listener);
	}	
	
	@Override
	public void mousePressed(MouseEvent e){}
	
	public void mouseReleased(MouseEvent e){}
	
	
	public void mouseEntered(MouseEvent e){}
	
	public void mouseExited(MouseEvent e){}
	
	Graphics g2;
	
	@Override
	public void mouseClicked(MouseEvent e){}

	
	public void paint(Graphics g){
		super.paint(g);
		
	
	}
	
	
	
	public static void main(String[] args){
		new Draw();
	}
}
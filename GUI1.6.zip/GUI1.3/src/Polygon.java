
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;

public class Polygon extends Shape{

	public void draw(Graphics g){
	
	
		g.setColor(Color.black);
		g.translate(Draw.polygon_pos_x, Draw.polygon_pos_y);
		
		int thickness=Draw.flag_shapeThickness;
		
		//start - drawing the polygon
		if(Draw.flag_shapeProperties==1){
			
			Stroke solid = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0);
			Graphics2D g2 = (Graphics2D)g;
			
			for(int i=0;i<Draw.polygonX.length-1;i++){
			
				//drawing shape from respective x and y coordinates
				int x1=(int)Draw.polygonX[i];
				int y1=(int)Draw.polygonY[i];
				
				int x2=(int)Draw.polygonX[i+1];
				int y2=(int)Draw.polygonY[i+1];
				
				g2.setStroke(solid);
				g2.drawLine(x1,y1,x2,y2);   //from scale's centre
			}
		}
		
		else if(Draw.flag_shapeProperties==2){
			//Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{5,5}, 0);
			
			Stroke dotted = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0, new float[]{5,5}, 0);
			Graphics2D g2 = (Graphics2D)g;
			for(int i=0;i<Draw.polygonX.length-1;i++){
			
					
					int x1=(int)Draw.polygonX[i];
					int y1=(int)Draw.polygonY[i];
					
					int x2=(int)Draw.polygonX[i+1];
					int y2=(int)Draw.polygonY[i+1];
					
					g2.setStroke(dotted);
					g2.drawLine(x1,y1,x2,y2);
				
			}
		}
		
		else if(Draw.flag_shapeProperties==3){
			/*1*/
			//Stroke dashed = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {6,4,10,4}, 0);
			
			/*2*/
			Stroke dashed = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0, new float[] {6,4,10,4}, 0);
			
			
			Graphics2D g2 = (Graphics2D)g;
			for(int i=0;i<Draw.polygonX.length-1;i++){
				
				
				int x1=(int)Draw.polygonX[i];
				int y1=(int)Draw.polygonY[i];
				
				int x2=(int)Draw.polygonX[i+1];
				int y2=(int)Draw.polygonY[i+1];
				
				g2.setStroke(dashed);
				g2.drawLine(x1,y1,x2,y2);
				
			}
		}
		//end - drawing the polygon
		
		
	
	}
}


//for strokes: 
//check links---
//https://www.cs.tut.fi/lintula/manual/java/tutorial/2d/display/strokeandfill.html
//https://examplecode.wordpress.com/2010/02/03/how-to-draw-a-dotted-or-dashed-line-in-java/
//for scale:
//---
//https://examplecode.wordpress.com/2010/02/03/how-to-draw-a-dotted-or-dashed-line-in-java/
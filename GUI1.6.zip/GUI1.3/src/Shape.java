

import java.awt.Graphics;

public abstract class Shape {

    abstract public void draw(Graphics g);
}	

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.geom.Path2D;

public class Polygon extends Shape{

	public void draw(Graphics g){
	
		g.translate(Draw.polygon_pos_x, Draw.polygon_pos_y);
		
		int thickness=Draw.flag_shapeThickness;
		Stroke drawLineType = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0);
		//start - drawing the polygon
		if(Draw.flag_shapeProperties==1){
			
			drawLineType = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0);
			
		}
		
		else if(Draw.flag_shapeProperties==2){
			//Stroke dotted = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{5,5}, 0);
			
			drawLineType = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0, new float[]{5,5}, 0);
			
		}
		
		else if(Draw.flag_shapeProperties==3){
			/*1*/
			//drawLineType = new BasicStroke(1, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[] {6,4,10,4}, 0);
			
			/*2*/
			drawLineType = new BasicStroke(thickness, BasicStroke.CAP_ROUND, BasicStroke.JOIN_BEVEL, 0, new float[] {6,4,10,4}, 0);
			
		}

		Graphics2D g2 = (Graphics2D)g;
		
		Path2D path = new Path2D.Double();
		if(Draw.polygonX.length > 0)
		{
			int x=(int)Draw.polygonX[0];
			int y=(int)Draw.polygonY[0];
			path.moveTo(x, y);
		}
		for(int i=1;i<Draw.polygonX.length-1;i++){
			
			
			int x=(int)Draw.polygonX[i];
			int y=(int)Draw.polygonY[i];
			
			path.lineTo(x, y);
			
		}
		path.closePath();
		
		g2.setStroke(drawLineType);
		
		g2.setColor(shapeColor);
		g2.fill(path);
		
		g2.setColor(lineColor);
		g2.draw(path);
		
		//end - drawing the polygon
		
		
	
	}
}


//for strokes: 
//check links---
//https://www.cs.tut.fi/lintula/manual/java/tutorial/2d/display/strokeandfill.html
//https://examplecode.wordpress.com/2010/02/03/how-to-draw-a-dotted-or-dashed-line-in-java/
//for scale:
//---
//https://examplecode.wordpress.com/2010/02/03/how-to-draw-a-dotted-or-dashed-line-in-java/
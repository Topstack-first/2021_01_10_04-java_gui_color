

import java.awt.Color;
import java.awt.Graphics;

public abstract class Shape {

	public Color shapeColor = Color.black;
	public Color lineColor = Color.black;
    abstract public void draw(Graphics g);
}	